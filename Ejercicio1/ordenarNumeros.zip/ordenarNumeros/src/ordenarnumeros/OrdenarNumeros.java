/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ordenarnumeros;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author diego
 */
public class OrdenarNumeros {

    public static void main(String[] args) {

        try {

            InputStreamReader isr = new InputStreamReader(System.in);
            BufferedReader br = new BufferedReader(isr);
            ArrayList aListNumeros = new ArrayList();
            String linea = br.readLine();
            int numeroEntrada;

            while ((linea = br.readLine()) != null) {

                numeroEntrada = Integer.parseInt(linea);
                aListNumeros.add(numeroEntrada);

            }

            Collections.sort(aListNumeros);
            System.out.println(aListNumeros);

        } catch (IOException ex) {

            System.err.println("Se ha producido un error de entrada y/o salida");
            Logger.getLogger(OrdenarNumeros.class.getName()).log(Level.SEVERE, null, ex);

        }
    }
}
