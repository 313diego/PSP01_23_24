/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package aleatoriosnumeros;

/**
 *
 * @author diego
 */
public class AleatoriosNumeros {

    public static void main(String[] args) {

        int numero;

        for (int i = 0; i < 40; i++) {

            numero = (int) (Math.random() * 100 + 1);

            System.out.println(numero);

        }

    }

}
