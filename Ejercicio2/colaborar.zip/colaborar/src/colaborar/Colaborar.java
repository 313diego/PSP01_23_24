/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package colaborar;

import java.io.IOException;

/**
 *
 * @author diego
 */
public class Colaborar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException { // Capturamos excepcion

        if (args.length == 1) { // Controlammos que introduzca al menos un parametro.
            for (int i = 1; i <= 5; i++) { // Debe de repetirse 5 veces

                System.out.println("Lanzamos el proceso: " + i);

                String comando = "java -jar lenguaje.jar " + i + " " + args[0];

                Runtime.getRuntime().exec(comando);

                System.out.println("Comando " + i + " lanzado.");

            }
        } else {
            System.out.println("Debe de introducir al menos un parametro "
                    + "(nombre del fichero)");

        }
    }

}
