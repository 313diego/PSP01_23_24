/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lenguaje;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.channels.FileLock;

/**
 *
 * @author diego
 */
public class Lenguaje {

    public static void main(String[] args) {
        try { // Controlamos excepcion de los argumentos

            if (args.length != 2) {
                System.out.println("Faltan argumentos");
            }

            try { // Controlamos excepcion de caracteres y repeticiones

                int numRep = Integer.parseInt(args[0]);
                /*variable para el 
                    numero de letras y palabras que vamos a crear.*/

                try { // Controlamos el poner el nómbre del archivo

                    String cadena = ""; // Cadena que contiene cada palabra
                    FileLock lock; // Variable de bloqueo del fichero
                    String nombreFichero; // Variable del nombre del fichero
                    String osName = System.getProperty("os.name");
                    // Variable para el nombre del sistema operativo
                    /* Controlamos que sistema operativo es para crear
                        correctamente el fichero.*/
                    if (osName.toUpperCase().contains("WIN")) {
                        nombreFichero = args[1].replace("\\", "\\\\");
                    } else {
                        nombreFichero = args[1];
                    }
                    // Creamos el fichero
                    File fichero = new File(nombreFichero);
                    /* Si el fichero no existe lo creamos, si existe
                        escribimos en el. */
                    if (!fichero.exists()) {
                        fichero.createNewFile();
                        System.out.println("Fichero creado");
                    } else {
                        System.out.println("Sobreescribiendo en el fichero"
                                + nombreFichero);
                    }

                    /* Creamos un acceso random al fichero dandole los
                        permisos necesarios (rwd)*/
                    RandomAccessFile raf = new RandomAccessFile(fichero, "rwd");
                    // Bloqueamos el fichero.
                    lock = raf.getChannel().lock();
                    /* Nos situamos despues de la última líne escrita del 
                        fichero si la hubiese. */
                    raf.seek(fichero.length());
                    /* Cremos dos bubles for, uno para crar cada una de las
                        letras dentro de la palabra y otro para crear cada una
                        de las palabaras.*/
                    for (int i = 0; i < numRep; i++) {
                        for (int r = 0; r < numRep; r++) {
                            /* Mediandte el metodo random elegimos al azar
                                una letra en minuscula de las existentes en el 
                                código ascii que van del rando 97 al 122 */
                            int codAscii = (int) Math.floor(Math.random() * (122 - 97) + 97);
                            // Guardamos cada una de esas letras en su variable
                            cadena = cadena + (char) codAscii;
                        }
                        // Escribirmos cada palabra en el fichero
                        raf.writeChars("Palabra " + (i + 1) + ": " + cadena + "\n");
                        // Mostramos por pantalla cada palabra creada
                        System.out.println("Palabra " + (i + 1) + ": " + cadena);
                        // Vaciamos el String para almacenar la numeva palabra
                        cadena = "";
                    }

                    lock.release(); // Liberamos el hilo
                    lock = null; // Vaciamos la variable look
                    raf.close(); // Cerramos el random access file

                } catch (Exception i) {
                    System.out.println("Debe indicar el nombre del archivo");
                }

            } catch (NumberFormatException e) {
                System.out.println("Debe indicar un número de caracteres y"
                        + " repeticiones");
            }

        } catch (ArrayIndexOutOfBoundsException a) {
            System.out.println("Debe de introducir dos parametros (número "
                    + "de letras y repeticiones mas el nombre del fichero y "
                    + "su extensión");
        }
    }

}
